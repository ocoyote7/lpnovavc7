export { POST } from "../pix/route"
